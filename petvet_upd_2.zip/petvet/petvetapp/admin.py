from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Login)
admin.site.register(Customer)
admin.site.register(Dogwalkers)
admin.site.register(VeterinaryDoctors)
admin.site.register(clinic)
admin.site.register(Petshops)
admin.site.register(PetcareCentre)
admin.site.register(Complaint)
admin.site.register(Bookingdoctor)
admin.site.register(BookingDogwalker)
admin.site.register(Pet)
admin.site.register(Product)
admin.site.register(CentreAddservices)
admin.site.register(Cart)
admin.site.register(Order)
admin.site.register(BookCarecentre)

