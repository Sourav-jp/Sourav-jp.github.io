from django.shortcuts import render,redirect,HttpResponse,HttpResponseRedirect
from .models import *
from django.contrib.auth import authenticate
from datetime import datetime
import time
from django.contrib import messages
from django.db.models import Sum
from django.shortcuts import get_object_or_404

# Create your views here.
def index(request):
    return render(request,'index.html')

def login(request):
    if request.POST:
        username=request.POST['Email']
        Password=request.POST['Password']
        print(username,'##',Password)
        user=authenticate(username=username,password=Password)
        print(user)
        if user is not None:
            # login(request,user)
            if user.usertype=='admin':
                id=user.id
                request.session['uid']=id
                msg="login successfully"
                messages.info(request,msg)
                print("msg",msg)
                return HttpResponse("Success")
            elif user.usertype=='user':
                id=user.id
                request.session['uid']=id
                msg="login successfully"
                messages.info(request,msg)
                print("msg",msg)
                return HttpResponse("Success")
            elif user.usertype=='clinic':
                id=user.id
                request.session['uid']=id
                msg="login successfully"
                messages.info(request,msg)
                print("msg",msg)
                return HttpResponse("Success")
            elif user.usertype=='dogwalker':
                id=user.id
                request.session['uid']=id
                msg="login successfully"
                messages.info(request,msg)
                print("msg",msg)
                return HttpResponse("Success")
            elif user.usertype=='centre':
                id=user.id
                request.session['uid']=id
                msg="login successfully"
                messages.info(request,msg)
                print("msg",msg)
                return HttpResponse("Success")
            elif user.usertype=='shop':
                id=user.id
                request.session['uid']=id
                request.session['type']='shop'
                messages.info(request,"Login Successfull")
                return HttpResponse("Success")
            else:
                messages.info(request,"username or password invalid")
                return redirect('/login')
    return render(request,'login.html')


def customer_Register(request):
    if request.POST:
        name=request.POST['Username']
        email=request.POST['Email']
        password=request.POST['Password']
        Address=request.POST['Address']
        phonenumber=request.POST['phone']
        district=request.POST['district']
        
        if Login.objects.filter(username=email).exists():
            print("user already exists")
            msg="user already exists"
            messages.info(request,msg)
        else:
            q=Login.objects.create_user(username=email,usertype='user',password=password,viewpassword=password)
            q.save()
            regqry=Customer.objects.create(customer_name=name,district=district,email=email,Address=Address,phonenumber=phonenumber,user=q)
            regqry.save()
            msg="Customer Registered Successfully"
            messages.info(request,msg)
            print("msg",msg)
            
        return redirect('/login')

    return render(request,'customer_register.html')
    


def clinic_register(request):
    if request.POST:
        name=request.POST['clinicname']
        email=request.POST['Email']
        password=request.POST['Password']
        Address=request.POST['Address']
        phonenumber=request.POST['phone']
        owned=request.POST['owned_by']
        license_no=request.POST['license']
        district=request.POST['district']
        start=request.POST['start']
        end=request.POST['end']
        
        if clinic.objects.filter(email=email,phonenumber=phonenumber).exists():
            print("user already exists")
            msg="user already exists"
            messages.info(request,msg)
        else:
            q=Login.objects.create_user(username=email,usertype='clinic',password=password,viewpassword=password,is_active=0)
            q.save()
            regqry=clinic.objects.create(clinic_name=name,district=district,starttime=start,Endtime=end,license_no=license_no,email=email,Address=Address,phonenumber=phonenumber,owned_by=owned,user=q)
            regqry.save()
            msg="Veterinary Clinics Registered Suceesfully."
            messages.info(request,msg)
            print("msg",msg)
    
            
        return redirect('/login')

    return render(request,'clinics_register.html')


def dogwalker_register(request):
    if request.POST:
        name=request.POST['name']
        email=request.POST['Email']
        password=request.POST['Password']
        Address=request.POST['Address']
        phonenumber=request.POST['phone']
        licence_no=request.POST['license']
        district=request.POST['district']
        
        if Dogwalkers.objects.filter(email=email,phonenumber=phonenumber).exists():
            print("user already exists")
            msg="user already exists"
            messages.info(request,msg)
        else:
            q=Login.objects.create_user(username=email,usertype='dogwalker',password=password,viewpassword=password,is_active=0)
            q.save()
            regqry=Dogwalkers.objects.create(name=name,district=district,license_no=licence_no,email=email,Address=Address,phonenumber=phonenumber,user=q)
            regqry.save()
            msg="Dog Walkers Registered Successfully"
            messages.info(request,msg)
            print("msg",msg)
    
            
        return redirect('/login')

    return render(request,'dogwalkers.html')

def carecentre_register(request):
    if request.POST:
        name=request.POST['centrename']
        email=request.POST['Email']
        password=request.POST['Password']
        Address=request.POST['Address']
        phonenumber=request.POST['phone']
        owner=request.POST['owner']
        licence_no=request.POST['license']
        district=request.POST['district']
        if PetcareCentre.objects.filter(email=email,phonenumber=phonenumber).exists():
            print("user already exists")
            msg="user already exists"
            messages.info(request,msg)
        else:
            q=Login.objects.create_user(username=email,usertype='centre',password=password,viewpassword=password,is_active=0)
            q.save()
            regqry=PetcareCentre.objects.create(carecentre=name,district=district,license_no=licence_no,email=email,Address=Address,phonenumber=phonenumber,owner_name=owner,user=q)
            regqry.save()
            msg="Pet Care Centres Registerd Successfully"
            messages.info(request,msg)
            print("msg",msg)
        
        return redirect('/login')

    return render(request,'carecentre_register.html')

def petshop_register(request):
    if request.POST:
        name=request.POST['shopname']
        email=request.POST['Email']
        password=request.POST['Password']
        Address=request.POST['Address']
        phonenumber=request.POST['phone']
        owner=request.POST['ownername']
        licence_no=request.POST['license']
        district=request.POST['district']
        if Petshops.objects.filter(email=email,phonenumber=phonenumber).exists():
            print("user already exists")
            msg="user already exists"
            messages.info(request,msg)
        else:
            q=Login.objects.create_user(username=email,usertype='shop',password=password,viewpassword=password,is_active=0)
            q.save()
            regqry=Petshops.objects.create(shop_name=name,district=district,license_no=licence_no,email=email,Address=Address,phonenumber=phonenumber,owner_name=owner,user=q)
            regqry.save()
            msg="Pet Shops Registered successfully"
            messages.info(request,msg)
            print("msg",msg)
            
        return redirect('/login')

    return render(request,'petshop_register.html')



###################  ADMIN ##################









