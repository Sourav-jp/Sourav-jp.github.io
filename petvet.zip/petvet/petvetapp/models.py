from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class Login(AbstractUser):
    usertype=models.CharField(max_length=40,null=True)
    viewpassword=models.CharField(max_length=40,null=True)

class Customer(models.Model):
    customer_name=models.CharField(max_length=50,null=True)
    email=models.CharField(max_length=50,null=True)
    Address=models.CharField(max_length=60,null=True)
    phonenumber=models.CharField(max_length=40,null=True)
    user=models.ForeignKey(Login,on_delete=models.CASCADE,null=True)
    district=models.CharField(max_length=50,null=True)
    
class Dogwalkers(models.Model):
    name=models.CharField(max_length=50,null=True)
    email=models.CharField(max_length=50,null=True)
    Address=models.CharField(max_length=50,null=True)
    phonenumber=models.CharField(max_length=50,null=True)
    license_no=models.CharField(max_length=50,null=True)
    user=models.ForeignKey(Login,on_delete=models.CASCADE,null=True)
    charge=models.IntegerField(null=True)
    district=models.CharField(max_length=50,null=True)


class clinic(models.Model):
    clinic_name=models.CharField(max_length=50,null=True)
    email=models.CharField(max_length=50,null=True)
    Address=models.CharField(max_length=50,null=True)
    phonenumber=models.CharField(max_length=50,null=True)
    owned_by=models.CharField(max_length=50,null=True)
    license_no=models.CharField(max_length=50,null=True)
    user=models.ForeignKey(Login,on_delete=models.CASCADE,null=True)
    starttime=models.TimeField(null=True)
    Endtime=models.TimeField(null=True)
    district=models.CharField(max_length=50,null=True)

class VeterinaryDoctors(models.Model):
    name=models.CharField(max_length=50,null=True)
    phonenumber=models.CharField(max_length=50,null=True)
    register_no=models.CharField(max_length=50,null=True)
    qualification=models.CharField(max_length=50,null=True)
    clinic=models.ForeignKey(clinic,on_delete=models.CASCADE,null=True)
    
class Petshops(models.Model):
    shop_name=models.CharField(max_length=60,null=True)
    owner_name=models.CharField(max_length=60,null=True)
    email=models.CharField(max_length=50,null=True)
    Address=models.CharField(max_length=50,null=True)
    phonenumber=models.CharField(max_length=50,null=True)
    license_no=models.CharField(max_length=50,null=True)
    user=models.ForeignKey(Login,on_delete=models.CASCADE,null=True)
    district=models.CharField(max_length=50,null=True)

class PetcareCentre(models.Model):
    carecentre=models.CharField(max_length=50,null=True)
    email=models.CharField(max_length=50,null=True)
    Address=models.CharField(max_length=50,null=True)
    phonenumber=models.CharField(max_length=50,null=True)
    owner_name=models.CharField(max_length=50,null=True)
    license_no=models.CharField(max_length=50,null=True)
    user=models.ForeignKey(Login,on_delete=models.CASCADE,null=True)
    district=models.CharField(max_length=50,null=True)
