from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Login)
admin.site.register(Customer)
admin.site.register(Dogwalkers)
admin.site.register(VeterinaryDoctors)
admin.site.register(clinic)
admin.site.register(Petshops)
admin.site.register(PetcareCentre)
